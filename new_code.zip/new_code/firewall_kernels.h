#ifndef FIREWALL_KERNELS_H
#define FIREWALL_KERNELS_H

#include "rules.h"

void run_firewall(char*, char*, int*, int, int, unsigned long*, int, unsigned int*, unsigned long*);

#endif
